#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __APPLE__
#include <OpenAL/al.h>
#include <OpenAL/alc.h>
#else
#include <AL/al.h>
#include <AL/alc.h>

#include "wav.h"
#include "mp3.h"

#endif

int main(int argc, char *argv[]) {
    if (argc != 2) {
    	return 1;
    }

    const char *check = argv[1];
    uint8_t len = strlen(check);
    const char *lastFour = &check[len-4];


    if(!strncmp(lastFour, ".wav", 4)){
        playWAVE(argv[1]);
        return 0;
    } else if(!strncmp(lastFour, ".mp3", 4)) {
        playMP3(argv[1]);
        return 0;
    } else {
        printf("Not a valid file\n");
        return 1;
    }
}