#ifndef MP3_H
#define MP3_H

#define BITS 8
int playMP3(char *path);

#endif