#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef __APPLE__
#include <OpenAL/al.h>
#include <OpenAL/alc.h>
#else
#include <AL/al.h>
#include <AL/alc.h>

#include "wav.h"
#include "mp3.h"

#endif

int main(int argc, char *argv[]) {

    if(!strcmp(argv[1], "-h")){
        printf("./waveplayer -<option: mp, w, h> <corresponding file>\n");
        return 0;
    } else if(!strcmp(argv[1], "-w")){
        playWAVE(argv[2]);
        return 0;
    } else if(!strcmp(argv[1], "-mp")){
        playMP3(argv[2]);
        return 0;
    } else {
        printf("Not a valid option\n");
        return 1;
    }
    
}