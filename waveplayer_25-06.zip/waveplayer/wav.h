#ifndef WAV_H
#define WAV_H

struct __attribute__((__packed__)) wav_header_t;

int playWAVE(char *path);

#endif